#!/bin/bash

for F in "$@"; do
  if test -f $F; then
    echo $F
    c=`cat $F | wc -c`
    echo $c
    l=`cat $F | wc -l`
    echo $l
  fi
 if test -d $F;then
   echo $F
   c=0
  for G in `find $F -type f`; do
     c=`expr $c + 1`
  done
  for H in `find $F -type d`; do
    for G in `find $H -type f`; do
      c=`expr $c + 1`
    done
   done
  echo $c
  fi   
done
