#!/bin/bash
  
for F in `find $1 -type f`; do
 if find $F  -perm 755; then
    read command
     if "$command" == "yes";then
       chmod 744 $F
     fi
  fi
done

for F in `find $1 -type d`; do
  for G in `find $F -type f`; do
     if find $G  -perm 755; then
       read command
       if "$command" == "yes";then
         chmod 744 $G
       fi
     fi
  done
done
     
