#!/bin/bash

for F in `find $1 -type f`; do
 if grep "[0-9]\{6,\}" $F; then
   echo $F
 fi
done
