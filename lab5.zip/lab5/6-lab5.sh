#!/bin/bash

for F in "$@"; do
  fisier=$1
  shift
  cuv=$1
  shift
  k=$1
  shift
  grep -q "\(*/<$cuv\>*\)\{$k\}" $fisier | awk -F'\n' '{print $1}'
done 
