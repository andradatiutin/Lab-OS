!/bin/bash

for F in "$@"; do
  if test -f $F; then
    sort $F | uniq -c |sort -n -r |  head -1
  fi
done
