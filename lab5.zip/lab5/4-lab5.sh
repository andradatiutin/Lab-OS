#!/bin/bash
  
for F in `find $1 -type f`; do
 if find $F  -perm 777; then
   echo $F
 fi
done

for F in `find $1 -type d`; do
  for G in `find $F -type f`; do
     if find $G  -perm 777; then
  	 echo $G
      fi
  done
done 
