#!/bin/bash

sum=0
cnt=0
for F in `find $1 -type f`; do
 c=`cat $F | wc -l`
 sum=`expr $sum + $c`
 cnt=`expr $cnt + 1`
done
echo "sum: $sum; cnt: $cnt; avg:$(($sum/$cnt))"
