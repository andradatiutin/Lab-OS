#!/bin/bash

for F in `find $1 -type f -name "?\(0,7\)"`; do
    echo $F
done

for F in `find $1 -type d`; do
  for G in `find $F -type f-name "?\(0,7\)"`; do
     if grep -q "^.\(0,7\)$" $G; then
         echo $G
      fi
  done
done
