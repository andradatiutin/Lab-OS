#!/bin/bash
  
for F in `find $1 -type f -name "*.txt"`; do
 c=`cat $F | wc -l`
 echo $c
  if test $c -lt 10; then
   cat $F
 else
   cat $F | head -5
   cat $F | tail -5
 fi
done
