#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc,char** argv) {
   int i, j, k=0;
   i = fork();
   if ((j = fork())) {
     k = fork();
   }
   printf(" %d %d %d %d %d\n ", i, j, k, getpid(), getppid());
}
