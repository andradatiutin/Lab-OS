#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc,char** argv){
  if(fork()==0)
  {
   execlp(argv[1],argv[1],NULL);
   exit(0);
  }
  printf("HERE!");
  return 0;
}  

