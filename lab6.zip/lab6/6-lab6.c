#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc,char** argv){
  int N=0;
  scanf("%d",&N);
  int p2a[2],a2p[2];
  pipe(p2a);
  pipe(a2p);
  int i;
  int pid=fork();
  if(pid==0)
    {
    close(p2a[1]);
    close(a2p[0]);
     int n,ok=1;
     read(p2a[0],&n,sizeof(int));
     if((n<=1||n%2==0)&&n!=2)
       ok=0;
     int i;
     for(i=3;i<=n/2;i++)
       if(n%i==0)
         ok=0;
     write(a2p[1],&ok,sizeof(int));
     close(p2a[0]);
     close(a2p[1]);
     exit(0);
     }
   for(i=1;i<=N;i++)
   {
    int a;
    close(p2a[0]);
    close(a2p[1]);
    write(p2a[1],&i,sizeof(int));
    read(a2p[0],&a,sizeof(int));
    if(a==1)
       printf("%d",a);
   }
   close(p2a[0]);
   close(a2p[1]);
   wait(0);
   return 0;
}
