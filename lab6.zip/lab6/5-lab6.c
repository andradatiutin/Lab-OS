#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc,char** argv) {
  int n,v[100],i;
  scanf("%d",&n);
  for(i=0;i<n;i++)
     scanf("%d",&v[i]);
  int pid,sum=0,s=0;
  pid=fork();
  if(pid==0)
  {
   for(i=0;i<n;i++)
     if(v[i]%2==1)
       s+=v[i];
   exit(0);
  }
  for(i=0;i<n;i++)
     if(v[i]%2==0)
       sum+=v[i];
   wait(0);
   sum+=s;
   printf("%d",sum);
   return 0;
}
   
